#include<iostream>
#include"console.h"
using namespace std;

int PriorityQueueUnitTest();
int BigIntTest();
int StringMapTest();

int main(){
    cout<<"Problem1:"<<endl;
    PriorityQueueUnitTest();
    cout<<"Problem2:"<<endl;
    BigIntTest();
    cout<<"Problem3,4:"<<endl;
    StringMapTest();
    return 0;
}
